package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import vo.PlaneVO;
import vo.UserVO;

public class UserDAO {
	
	public static ArrayList<UserVO> userList = new ArrayList<UserVO>();//user�� ����Ʈ
	
	
	
	//user�� �̸����� ����� ����Ʈ
	static public void delete_user(String name) {
		for (int i = 0; i < userList.size(); i++) {
			if(name.equals(userList.get(i).getName()))
				{
					userList.remove(i);
					break;
				}
		}
		System.out.println("user delete complete");
	}
	
	
	//user ������ ���α׷�->�ؽ�Ʈ ���Ϸ� ���ε�
		public static void upload_user() throws Exception {
			File user_list = new File(".//src//userList.txt");
			BufferedWriter bw= new BufferedWriter(new FileWriter(user_list));
			String line ="���̵�,��й�ȣ,�̸�,�̸���,���ϸ���,�������ΰ�,�����װ�����"+"\r\n";
			bw.write(line);
			bw.flush();
			for (int i = 0; i < userList.size(); i++) {
				UserVO temp =userList.get(i);
				line = temp.getID()+","+temp.getPw()+","+temp.getName()+","+temp.getEmail()+","+temp.getMileage();
				for (int j = 0; j < temp.getMy_plane().size(); j++) {
					PlaneVO tempPlane=temp.getMy_plane().get(j);
					line+=","+tempPlane.getDate() + "," + tempPlane.getBrand_plane() + "," + tempPlane.getNum_plane() + ","
							+ tempPlane.getTime() + "," + tempPlane.getS_day() + "," + tempPlane.getE_day() + ","
							+ tempPlane.getS_locate() + "," + tempPlane.getE_locate() + "," + tempPlane.getSeat();
				}
				line+="\r\n";
				bw.write(line);
				bw.flush();
			}
			System.out.println("user upload complete");
		}
	
	
	
	
	//user ������ �ؽ�Ʈ����->���α׷����� �ٿ�ε�
		public static void download_user() throws Exception {
			File user_list = new File(".//src//userList.txt");
			BufferedReader br = new BufferedReader(new FileReader(user_list));
			String line = "";
			line = br.readLine();
			while ((line = br.readLine()) != null) {
				String[] token = line.split(",", -1);
				ArrayList<PlaneVO> arP= new ArrayList<>();
				for (int i = 5; i < token.length; i=i+9) {
					PlaneVO temp=new PlaneVO();
					temp.setDate(token[i]);
					temp.setBrand_plane(token[i+1]);
					temp.setNum_plane(token[i+2]);
					temp.setTime(token[i+3]);
					temp.setS_day(token[i+4]);
					temp.setE_day(token[i+5]);
					temp.setS_locate(token[i+6]);
					temp.setE_locate(token[i+7]);
					temp.setSeat(Integer.parseInt(token[i+8]));
					arP.add(temp);
					}
				userList
						.add(new UserVO(token[0], token[1], token[2], token[3], Integer.parseInt(token[4]),arP));
			}
			br.close();
			System.out.println("user download complete");
		}
}
