package snippet;

public class Snippet {
			String[] type = { "�ǳ�", "�ǿ�" };
}

