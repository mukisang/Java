package dao;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.AbstractListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import vo.PlaneVO;

//�� ���� ������
public class FrameMainDAO extends JFrame {

	// panel���� ������ �ִ� ��
	public static login Login;
	public static join Join;
	public static intro Intro;
	/* public static list List; */
	/* public static admin Admin; */

	Dimension dimen, dimen2;
	static int xpos = 0;
	static int ypos = 0;
	private JPanel contentPane;

	// ���� �޼���
	public static void start() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// ���⿡�� �ش� ������ �߰�
					FrameMainDAO frame = new FrameMainDAO();
					frame.Login = new login(frame);
					frame.Join = new join(frame);
					frame.Intro = new intro(frame);
					/* frame.Admin = new admin(frame); */
					/* frame.List = new list(frame); */

					frame.setVisible(true);
					frame.add(Intro);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// â�� ��ȯ�����ִ� �޼���
	public void changePanel(String panelName) {
		if (panelName.equals("join")) {
			getContentPane().removeAll();
			getContentPane().add(Join);
			revalidate();
			repaint();
		} else if (panelName.equals("login")) {
			getContentPane().removeAll();
			getContentPane().add(Login);
			revalidate();
			repaint();
		} else if (panelName.equals("intro")) {
			getContentPane().removeAll();
			getContentPane().add(Intro);
			revalidate();
			repaint();
		} /*
			 * else if (panelName.equals("admin")) { getContentPane().removeAll();
			 * getContentPane().add(Admin); revalidate(); repaint();
			 */
		/*
		 * } else if (panelName.equals("list")) { getContentPane().removeAll();
		 * getContentPane().add(List); revalidate(); repaint(); }
		 */
	}

	public FrameMainDAO() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrameMainDAO.class.getResource("/img/main.png")));
		setForeground(Color.WHITE);
		setBackground(Color.WHITE);
		setBounds(1200, 100, 950, 770);
		dimen = Toolkit.getDefaultToolkit().getScreenSize();
		dimen2 = getSize();
		xpos = (dimen.width - dimen2.width) / 2;
		ypos = (dimen.height - dimen2.height) / 2;
		setLocation(xpos, ypos);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
}

//intro â
class intro extends JPanel {
	private FrameMainDAO f;

	public intro(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(intro.class.getResource("/img/ve1.png")));

		JButton btnNewButton = new JButton("");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("login");
			}
		});
		btnNewButton.setIcon(new ImageIcon(intro.class.getResource("/img/ve3.png")));
		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane
				.setHorizontalGroup(
						gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(233, Short.MAX_VALUE)
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 500,
												GroupLayout.PREFERRED_SIZE)
										.addGap(189))
								.addGroup(Alignment.LEADING,
										gl_contentPane.createSequentialGroup().addGap(360)
												.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 173,
														GroupLayout.PREFERRED_SIZE)
												.addContainerGap(389, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(76).addComponent(lblNewLabel).addGap(78)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(90, Short.MAX_VALUE)));
		this.setLayout(gl_contentPane);
	}

}

//�α��� â
class login extends JPanel {
	private FrameMainDAO f;
	private JTextField textField;
	private JPasswordField textField_1;

	public login(FrameMainDAO f) {
		this.f = f;
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login1.png")));
		this.setBackground(Color.WHITE);
		textField = new JTextField();
		textField.addMouseListener(new MouseAdapter() {
			@Override

			public void mouseClicked(MouseEvent arg0) {
				textField.setText("");
			}
		});
		textField.setText("\uC544\uC774\uB514\uB97C \uC785\uB825\uD558\uC138\uC694");
		textField.setForeground(Color.GRAY);
		textField.setColumns(10);

		textField_1 = new JPasswordField();
		textField_1.addMouseListener(new MouseAdapter() {
			@Override

			public void mouseClicked(MouseEvent e) {
				textField_1.setText("");
			}
		});

		textField_1.setText("1234");
		textField_1.setForeground(Color.GRAY);
		textField_1.setColumns(10);

		JButton btnNewButton = new JButton("New button");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String id;
				String pw;
				int choice;
				id = textField.getText();
				pw = textField_1.getText();
				choice = UserDAO.login(id, pw);
				if (choice == -1) {
					f.changePanel("admin");
				} else if (choice == 1) {
					f.changePanel("list");
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login_but.png")));

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login2.png")));

		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login3.png")));

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/join_but.png")));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("join");
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addGap(77)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
						.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false).addComponent(textField_1)
								.addComponent(textField, GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE))
						.addGap(51)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 189, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 740, GroupLayout.PREFERRED_SIZE))
				.addContainerGap(105, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(52)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(10)
										.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 529,
												GroupLayout.PREFERRED_SIZE)
										.addGap(41).addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 119,
												GroupLayout.PREFERRED_SIZE))
								.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 757, Short.MAX_VALUE))
						.addGap(113)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap()
				.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 324, GroupLayout.PREFERRED_SIZE).addGap(51)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnNewButton, 0, 0, Short.MAX_VALUE))
				.addGap(18).addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
				.addGap(18)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
				.addGap(28)));
		this.setLayout(gl_contentPane);
	}
}

//ȸ������â
class join extends JPanel {
	private FrameMainDAO f;
	private JTextField textField_2;
	private JPasswordField passwordField;
	private JTextField textField;
	private JTextField textField_1;

	public join(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel lblJoin = new JLabel("");
		lblJoin.setIcon(new ImageIcon(join.class.getResource("/img/join1.PNG")));

		JButton button = new JButton("");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ���ԿϷ��ư
				String name, ID, pw, email;
				name = textField.getText();
				ID = textField_1.getText();
				pw = passwordField.getText();
				email = textField_2.getText();
				UserDAO.join(name, ID, pw, email);
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				passwordField.setText("");
				f.changePanel("login");
			}
		});
		button.setIcon(new ImageIcon(join.class.getResource("/img/join4.png")));

		JButton btnNewButton = new JButton("");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setText("");
				textField_1.setText("");

				textField_2.setText("");
				passwordField.setText("");
				f.changePanel("login");
			}
		});
		btnNewButton.setIcon(new ImageIcon(join.class.getResource("/img/join5.png")));

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(join.class.getResource("/img/join8.png")));

		textField = new JTextField();
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setColumns(10);

		passwordField = new JPasswordField();

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(38).addComponent(lblJoin))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(153)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 217, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(textField, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(192)
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 243, GroupLayout.PREFERRED_SIZE)
								.addGap(32).addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 244,
										GroupLayout.PREFERRED_SIZE)))
				.addContainerGap(41, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap().addComponent(lblJoin).addGap(18)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(48).addComponent(label,
								GroupLayout.PREFERRED_SIZE, 298, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(60)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)))
				.addGap(66)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
				.addGap(93)));

		this.setLayout(gl_contentPane);
	}
}
