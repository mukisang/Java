package dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import vo.PlaneVO;

public class SortDAO {

	
	
	
	public static ArrayList<String> popular() {
		sorting(1);
		int sum_reserved_seat = 0;
		int brandCnt = 0;
		int planeCnt = 0;
		int reserve_rate = 0;
		ArrayList<String> pop_list = new ArrayList<>();
		TreeMap<String, Integer> s_tMap = new TreeMap<>();
		TreeMap<String, Integer> e_tMap = new TreeMap<>();
		for (int i = 1; i < PlaneDAO.s_planeList.size() - 1; i++) {
			PlaneVO s_tempPlane = PlaneDAO.s_planeList.get(i);
			PlaneVO s_tempPlane_2 = PlaneDAO.s_planeList.get(i + 1);
			if (i == 1) {
				brandCnt++;
				planeCnt++;// �ش� �װ��翡 �����ϴ� �װ��� ����
				sum_reserved_seat += (300 - s_tempPlane.getSeat());// 300�� seat_size�� �����ϴ� ��...??
			}
			if (s_tempPlane.getBrand_plane().equals(s_tempPlane_2.getBrand_plane())) {
				sum_reserved_seat += (300 - s_tempPlane_2.getSeat());
				planeCnt++;
			} else {
				reserve_rate = (sum_reserved_seat / planeCnt) / 3;
				s_tMap.put(s_tempPlane.getBrand_plane(), reserve_rate);
				sum_reserved_seat = (300 - s_tempPlane_2.getSeat());
				planeCnt = 1;
				brandCnt++;
			}
		}
		Iterator s_itr = s_tMap.entrySet().iterator();
		Set s_set = s_tMap.entrySet();
		List s_list = new ArrayList(s_set);
		Collections.sort(s_list, new ValueComparator());
		s_itr = s_list.iterator();
		for (int i = 0; i < 5; i++) {
			Map.Entry s_entry = (Map.Entry) s_itr.next();
			int s_value = ((Integer) s_entry.getValue()).intValue();
			String s_valueString = "" + s_value;
			char[] charArray = s_entry.getKey().toString().toCharArray();

			if (charArray.length < 6) {
				pop_list.add(s_entry.getKey() + "\t\t" + s_valueString + "%");
			} else {
				pop_list.add(s_entry.getKey() + "\t" + s_valueString + "%");
			}
		}
		for (int i = 1; i < PlaneDAO.e_planeList.size() - 1; i++) {
			PlaneVO e_tempPlane = PlaneDAO.e_planeList.get(i);
			PlaneVO e_tempPlane_2 = PlaneDAO.e_planeList.get(i + 1);
			if (i == 1) {
				brandCnt++;
				planeCnt++;// �ش� �װ��翡 �����ϴ� �װ��� ����
				sum_reserved_seat += (300 - e_tempPlane.getSeat());// 300�� seat_size�� �����ϴ� ��...??
			}
			if (e_tempPlane.getBrand_plane().equals(e_tempPlane_2.getBrand_plane())) {
				sum_reserved_seat += (300 - e_tempPlane_2.getSeat());
				planeCnt++;
			} else {
				reserve_rate = (sum_reserved_seat / planeCnt) / 3;
				e_tMap.put(e_tempPlane.getBrand_plane(), reserve_rate);
				sum_reserved_seat = (300 - e_tempPlane_2.getSeat());
				planeCnt = 1;
				brandCnt++;
			}
		}
		Iterator e_itr = e_tMap.entrySet().iterator();
		Set e_set = e_tMap.entrySet();
		List e_list = new ArrayList(e_set);
		Collections.sort(e_list, new ValueComparator());
		e_itr = e_list.iterator();
		for (int i = 0; i < 5; i++) {
			Map.Entry e_entry = (Map.Entry) e_itr.next();
			int e_value = ((Integer) e_entry.getValue()).intValue();
			String e_valueString = "" + e_value;
			char[] charArray = e_entry.getKey().toString().toCharArray();

			if (charArray.length < 6) {
				pop_list.add(e_entry.getKey() + "\t\t" + e_valueString + "%");
			} else {
				pop_list.add(e_entry.getKey() + "\t" + e_valueString + "%");
			}

		}
		return pop_list;
	}

	static class ValueComparator implements Comparator {

		@Override
		public int compare(Object o1, Object o2) {
			if (o1 instanceof Map.Entry && o2 instanceof Map.Entry) {
				Map.Entry e1 = (Map.Entry) o1;
				Map.Entry e2 = (Map.Entry) o2;

				int v1 = ((Integer) e1.getValue()).intValue();
				int v2 = ((Integer) e2.getValue()).intValue();

				return v2 - v1;
			}
			return -1;
		}
	}

	// �ش� ������ �����ϴ� ����Ʈ �迭�� ����ϴ� �޼���
	static public void show_list(ArrayList<PlaneVO> temp, String stOrEnd, String s_locate, String e_locate,int date
			,int seat) {


		if (stOrEnd.equals("���"))// ����� ����
		{

			int size = PlaneDAO.s_planeList.size();

			Iterator<PlaneVO> itr = PlaneDAO.s_planeList.iterator();

			while (itr.hasNext()) {

				
				PlaneVO tmp2=itr.next();
				PlaneVO tmp =new PlaneVO(tmp2.getDate(), tmp2.getBrand_plane(), tmp2.getNum_plane(), tmp2.getTime(), tmp2.getS_day(), tmp2.getE_day(),
						tmp2.getS_locate(), tmp2.getE_locate(), tmp2.getSeat());
				
				if ((tmp.getS_locate().equals(s_locate) || s_locate.equals(""))
						&&(Integer.parseInt(tmp.getS_day())==date||date==0)
						&& (tmp.getE_locate().equals(e_locate) || e_locate.equals("")) && (tmp.getSeat() - seat >= 0)) {
					
					temp.add(tmp);
					
				}
			}

		} else if (stOrEnd.equals("����"))// ������ ����

		{
			int size = PlaneDAO.e_planeList.size();

			Iterator<PlaneVO> itr = PlaneDAO.e_planeList.iterator();

			while (itr.hasNext()) {

				PlaneVO tmp = itr.next();

				if ((tmp.getS_locate().equals(s_locate) ||s_locate.equals(""))
						&&(Integer.parseInt(tmp.getE_day())==date||date==0)
						&& (tmp.getE_locate().equals(e_locate) || e_locate.equals("")) && (tmp.getSeat() - seat >= 0)) {
					temp.add(tmp);
				}
			}
		} else// ����̳� ������ �ƴ� ���
		{
			System.out.println("�Է� ����(����̳� ���� ���� ����)");
		}
	}

	// ����� ���� �ð��� �ڵ����� �����ִ� �޼���
	static public int timeCompare(PlaneVO p1, PlaneVO p2) {
		String[] t1 = p1.getTime().split(":");
		String[] t2 = p2.getTime().split(":");
		if (Integer.parseInt(t1[0]) - Integer.parseInt(t2[0]) < 0
				|| Integer.parseInt(t1[0]) - Integer.parseInt(t2[0]) == 0
						&& Integer.parseInt(t1[1]) - Integer.parseInt(t2[1]) < 0)
			return -1;
		else if (Integer.parseInt(t1[0]) - Integer.parseInt(t2[0]) > 0
				|| Integer.parseInt(t1[0]) - Integer.parseInt(t2[0]) == 0
						&& Integer.parseInt(t1[1]) - Integer.parseInt(t2[1]) > 0)
			return 1;
		else
			return 0;
	}

	/*
	 * �װ������ Ư�� �������� ����(��������) 1. �װ��� o 2. ��߽ð� o 3. ��߳�¥ o 4. ������¥ o 5. ���� o 6. �ܿ�
	 * �¼� �� o
	 */
	public static void sorting(int num) {
		switch (num) {

		case 1:// �װ���
				// ��� �����
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				// �װ��� ���� �����ϴ� ���
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getBrand_plane().compareTo(p2.getBrand_plane()) < 0)
						return -1;
					else if (p1.getBrand_plane().compareTo(p2.getBrand_plane()) > 0)
						return 1;
					return 0;
				}
			});
			// ���������
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getBrand_plane().compareTo(p2.getBrand_plane()) < 0)
						return -1;
					else if (p1.getBrand_plane().compareTo(p2.getBrand_plane()) > 0)
						return 1;
					return 0;
				}
			});
			System.out.println("�װ��纰 ���� �Ϸ�");
			break;
		case 2:// ��߽ð�
				// ��� ������� ���� ��� �ð� ����������� ���� ���� �ð����� ����
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					return timeCompare(p1, p2);
				}

			});
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					return timeCompare(p1, p2);
				}
			});
			System.out.println("��� �ð��� ���� �Ϸ�");
			break;
		case 3:// ��߳�¥
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (Integer.parseInt(p1.getS_day()) - Integer.parseInt(p2.getS_day()) < 0)
						return -1;
					else if (Integer.parseInt(p1.getS_day()) - Integer.parseInt(p2.getS_day()) > 0)
						return 1;
					return 0;
				}
			});
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (Integer.parseInt(p1.getS_day()) - Integer.parseInt(p2.getS_day()) > 0)
						return 1;
					else if (Integer.parseInt(p1.getS_day()) - Integer.parseInt(p2.getS_day()) < 0)
						return -1;
					return 0;
				}
			});
			System.out.println("��߳�¥�� ���� �Ϸ�");
			break;
		case 4:// ������¥
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (Integer.parseInt(p1.getE_day()) - Integer.parseInt(p2.getE_day()) < 0)
						return -1;
					else if (Integer.parseInt(p1.getE_day()) - Integer.parseInt(p2.getE_day()) > 0)
						return 1;
					return 0;
				}
			});
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (Integer.parseInt(p1.getE_day()) - Integer.parseInt(p2.getE_day()) > 0)
						return 1;
					else if (Integer.parseInt(p1.getE_day()) - Integer.parseInt(p2.getE_day()) < 0)
						return -1;
					return 0;
				}
			});
			System.out.println("���� ��¥�� ���� �Ϸ�");
			break;
		case 5:// ����
				// ��� ������� ��� ��������
				// ���� ������� ��� �������
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getE_locate().compareTo(p2.getE_locate()) < 0)
						return -1;
					else if (p1.getE_locate().compareTo(p2.getE_locate()) > 0)
						return 1;
					return 0;
				}
			});
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getS_locate().compareTo(p2.getS_locate()) < 0)
						return -1;
					else if (p1.getS_locate().compareTo(p2.getS_locate()) > 0)
						return 1;
					return 0;
				}
			});
			System.out.println("������ ���� �Ϸ�");
			break;
		case 6:// �ܿ� �¼���
				// ��� ������� ��� ��������
				// ���� ������� ��� �������
			Collections.sort(PlaneDAO.s_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getSeat() - p2.getSeat() < 0)
						return -1;
					else if (p1.getSeat() - p2.getSeat() > 0)
						return 1;
					return 0;
				}
			});
			Collections.sort(PlaneDAO.e_planeList, new Comparator<PlaneVO>() {
				public int compare(PlaneVO p1, PlaneVO p2) {
					if (p1.getSeat() - p2.getSeat() < 0)
						return -1;
					else if (p1.getSeat() - p2.getSeat() > 0)
						return 1;
					return 0;
				}
			});
			System.out.println("�ܿ� �¼� ���� ���� �Ϸ�");
			break;
		default:
			System.out.println("���� ��ȣ �Է� ����");
			break;
		}

	}

}
