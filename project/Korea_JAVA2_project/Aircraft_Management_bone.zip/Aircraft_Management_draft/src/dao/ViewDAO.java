package dao;

import vo.AdmVO;

public class ViewDAO {
	
	// view��
		public void mainView() {
			try {
				AdmVO ad=AdmVO.getAdmin();//������ ����
				
				
				//��뿹��
				/*PlaneDAO.download_plist();
				PlaneDAO.upload_plist();*/
				
				//�����ϰ� ���� ���
				/*PlaneDAO.resetBeginning();
				PlaneDAO.upload_plist();*/
				
				
				
				
				/*SortDAO.favor_sort();
				
				*/
				
				UserDAO.download_user();
				/*UserDAO.delete_user("�̻�");*/
				UserDAO.upload_user();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
}
