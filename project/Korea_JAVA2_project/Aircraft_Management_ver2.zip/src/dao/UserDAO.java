package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import vo.PlaneVO;
import vo.UserVO;

public class UserDAO {

	public static ArrayList<UserVO> userList = new ArrayList<UserVO>();// user�� ����Ʈ

	
	
	//�α��� �޼���
	  public static int login(String ID , String pw) {
	         int isCheck = 0;//���д� 0, ������ 1, �����ڴ� -1   
	         
	         for (int i = 0; i < userList.size(); i++) {
	            if(ID.equals(userList.get(i).getID())) {
	               if (encrypt(pw).equals(userList.get(i).getPw())) {
	            	   System.out.println("�α��� ����");
	                  return isCheck=1;
	               }
	            }
	         }
	         if(ID.equals("root")&&pw.equals("1234"))
	        	 return -1;
	         System.out.println("�α��� ����");
	         return 0;
	      }
	      
	
	
	//ȸ������ �޼���
	static public boolean join(String name, String ID, String pw, String Email){
		if(name==null||ID==null||pw==null||Email==null)//�� â�� �ƹ��͵� ��ġ�� false
			return false;
		else//ȸ������ ���� �Է½�
		{
			String pwtemp = encrypt(pw);
			UserVO nu = new UserVO(ID, pwtemp, name, Email, 0);
			userList.add(nu);
			System.out.println("login success");
			return true;
		}
		
	}
	//��ȣȭ
	static public String encrypt(String pw) {
		String enPw = "";
		final int code =1;
		for (int i = 0; i < pw.length(); i++) {

			enPw += "" + (char) (pw.charAt(i) >> code);
		}
		return enPw;
	}
	//��ȣȭ �ص�
	static public String decrypt(String pw) {
		String dePw = "";
		final int code =1;
		for (int i = 0; i < pw.length(); i++) {
			dePw += "" + (char) (pw.charAt(i) << code);
		}
		return dePw;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// user�� �̸����� ����� ����Ʈ
	static public void delete_user(String name) {
		for (int i = 0; i < userList.size(); i++) {
			if (name.equals(userList.get(i).getName())) {
				userList.remove(i);
				break;
			}
		}
		System.out.println("user delete complete");
	}

	// user ������ ���α׷�->�ؽ�Ʈ ���Ϸ� ���ε�
	public static void upload_user() throws Exception {
		File user_list = new File(".//src//userList.txt");
		BufferedWriter bw = new BufferedWriter(new FileWriter(user_list));
		String line = "���̵�,��й�ȣ,�̸�,�̸���,���ϸ���,�����װ�����" + "\r\n";
		bw.write(line);
		bw.flush();
		for (int i = 0; i < userList.size(); i++) {
			UserVO temp = userList.get(i);		
			line = temp.getID() + "," + temp.getPw() + "," + temp.getName() + "," + temp.getEmail() + ","
					+ temp.getMileage();

			for (int j = 0; j < temp.getMy_plane().size(); j++) {
				PlaneVO tempPlane = temp.getMy_plane().get(j);
				line += "," + tempPlane.getDate() + "," + tempPlane.getBrand_plane() + "," + tempPlane.getNum_plane()
						+ "," + tempPlane.getTime() + "," + tempPlane.getS_day() + "," + tempPlane.getE_day() + ","
						+ tempPlane.getS_locate() + "," + tempPlane.getE_locate() + "," + tempPlane.getSeat();
				
			}
			line += "\r\n";
			bw.write(line);
			bw.flush();
		}
		System.out.println("user upload complete");
	}

	// user ������ �ؽ�Ʈ����->���α׷����� �ٿ�ε�
	public static void download_user() throws Exception {
		File user_list = new File(".//src//userList.txt");
		BufferedReader br = new BufferedReader(new FileReader(user_list));
		String line = "";
		line = br.readLine();
		while ((line = br.readLine()) != null) {
			String[] token = line.split(",", -1);
			ArrayList<PlaneVO> arP = new ArrayList<>();
			for (int i = 5; i < token.length; i = i + 9) {
				PlaneVO temp = new PlaneVO();
				temp.setDate(token[i]);
				temp.setBrand_plane(token[i + 1]);
				temp.setNum_plane(token[i + 2]);
				temp.setTime(token[i + 3]);
				temp.setS_day(token[i + 4]);
				temp.setE_day(token[i + 5]);
				temp.setS_locate(token[i + 6]);
				temp.setE_locate(token[i + 7]);
				temp.setSeat(Integer.parseInt(token[i + 8]));
				arP.add(temp);
			}
			userList.add(new UserVO(token[0], token[1], token[2], token[3], Integer.parseInt(token[4]), arP));
		}
		br.close();
		
		System.out.println("user download complete");
	}
}
