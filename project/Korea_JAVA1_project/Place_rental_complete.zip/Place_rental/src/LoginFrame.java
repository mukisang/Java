
//�α���ȭ���� �������Դϴ�.

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextField;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Frame;

import javax.jws.soap.SOAPBinding.Use;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
	static boolean isLog=false;
	String ID="java";
	String PW="java09";
	private JPanel contentPane;
	/**
	 * @wbp.nonvisual location=-200,414
	 */
	private final JTextField textField_1 = new JTextField();
	private final JLabel lblNewLabel = new JLabel("");
	private final Action action = new SwingAction();
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/
	void checkAndExit()
	{
		if(this.isLog==true)
		{
			
			this.dispose();
		}
			
	}
	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setTitle("\uB124\uC774\uBC84 \uB85C\uADF8\uC778");
		setIconImage(Toolkit.getDefaultToolkit().getImage("src\\img\\login_naver_icon.png"));
		textField_1.setColumns(10);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewLabel.setIcon(new ImageIcon("src\\img\\login_naver2.png"));
		lblNewLabel.setBounds(131, 12, 152, 57);
		
		contentPane.add(lblNewLabel);
		
		JTextArea username = new JTextArea();
		username.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				username.setText("");
			}
		});
		username.setFont(new Font("Monospaced", Font.ITALIC, 20));
		username.setText("\uC544\uC774\uB514");
		username.setBounds(46, 120, 339, 46);
		contentPane.add(username);
		
		JTextArea password = new JTextArea();
		password.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				password.setText("");
			}
		});
		password.setFont(new Font("Monospaced", Font.ITALIC, 20));
		password.setText("\uBE44\uBC00\uBC88\uD638");
		password.setBounds(46, 178, 339, 46);
		contentPane.add(password);
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String i_ID=username.getText();
				String i_PW=password.getText();
				if(i_ID.equals(ID)&&i_PW.equals(PW))
				{
					JOptionPane.showMessageDialog(null, "�α��� ����");
					isLog=true;
				}
				else
				{
					JOptionPane.showMessageDialog(null, "�α��� ����");
				}
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			
			public void mouseClicked(MouseEvent arg0) {
				/*String i_ID=username.getText();
				String i_PW=password.getText();
				if(i_ID.equals(ID)&&i_PW.equals(PW))
				{
					JOptionPane.showMessageDialog(null, "�α��� ����");
					isLog=true;
				}
				else
				{
					System.out.println("�α��� ����");
					
				}*/
			
			}
		});
		btnNewButton.setAction(action);
		btnNewButton.setIcon(new ImageIcon("src\\img\\login_button.png"));
		btnNewButton.setBounds(46, 265, 339, 46);
		contentPane.add(btnNewButton);
		contentPane.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{lblNewLabel, username, password, btnNewButton}));
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
			
		}
	}
}
