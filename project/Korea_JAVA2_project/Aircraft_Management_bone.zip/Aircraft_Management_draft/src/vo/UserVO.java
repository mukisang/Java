package vo;

import java.util.ArrayList;

public class UserVO {//����, �������� Ŭ����
	private String ID;
	private String pw;
	private String name;
	private String email;
	private int mileage;
	private ArrayList<PlaneVO> my_plane ;//���� ����� ���
	
	//������1 �ڵ����� plane�������
	public UserVO(String iD, String pw, String name, String email, int mileage)
	{
		this.ID = iD;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.mileage = mileage;
		this.my_plane = my_plane;
		ArrayList<PlaneVO> my_plane=new ArrayList<>();
	}

	
	
	//������2 planelist�޾ƿ�
	public UserVO(String iD, String pw, String name, String email, int mileage,
			ArrayList<PlaneVO> my_plane) {
		this.ID = iD;
		this.pw = pw;
		this.name = name;
		this.email = email;
		this.mileage = mileage;
		this.my_plane = my_plane;
	}



	
	public String getID() {
		return ID;
	}



	public void setID(String iD) {
		ID = iD;
	}



	public String getPw() {
		return pw;
	}



	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	public ArrayList<PlaneVO> getMy_plane() {
		return my_plane;
	}

	public void setMy_plane(ArrayList<PlaneVO> my_plane) {
		this.my_plane = my_plane;
	}
	
}//Ŭ���� ��
