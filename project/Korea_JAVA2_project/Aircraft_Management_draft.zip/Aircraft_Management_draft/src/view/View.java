package view;

import dao.PlaneDAO;

public class View {
	public static void main(String[] args) {
		new PlaneDAO().setting();
	}
}
