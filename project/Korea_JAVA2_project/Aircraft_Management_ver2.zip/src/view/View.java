package view;

import dao.PlaneDAO;
import dao.ViewDAO;


public class View {
	public static void main(String[] args) {
		new ViewDAO().mainView();
		
		
	}
}
