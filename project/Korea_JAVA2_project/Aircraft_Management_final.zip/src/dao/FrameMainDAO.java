package dao;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.AbstractListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import vo.PlaneVO;
import vo.UserVO;

//�� ���� ������
public class FrameMainDAO extends JFrame {

	// panel���� ������ �ִ� ��
	public static login Login;
	public static join Join;
	public static intro Intro;
	public static resv Resv;
	public static list_my List_M;
	public static admin Admin;
	public static admin_plane Admin_Plane;
	public static admin_user Admin_User;
	public static list_start List_Start;
	public static list_end List_End;

	Dimension dimen, dimen2;
	static int xpos = 0;
	static int ypos = 0;
	private JPanel contentPane;
	public PlaneVO temp_sp = new PlaneVO();
	public PlaneVO temp_ep = new PlaneVO();

	// ���� �޼���
	public static void start() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// ���⿡�� �ش� ������ �߰�
					FrameMainDAO frame = new FrameMainDAO();
					frame.Login = new login(frame);
					frame.Join = new join(frame);
					frame.Intro = new intro(frame);
					frame.Resv = new resv(frame);
					frame.List_M = new list_my(frame);
					frame.Admin = new admin(frame);
					frame.Admin_Plane = new admin_plane(frame);
					frame.Admin_User = new admin_user(frame);
					frame.List_Start = new list_start(frame);
					frame.List_End = new list_end(frame);
					/* frame.List = new list(frame); */

					frame.setVisible(true);
					frame.add(Intro);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// â�� ��ȯ�����ִ� �޼���
	public void changePanel(String panelName) {
		if (panelName.equals("join")) {
			getContentPane().removeAll();
			getContentPane().add(Join);
			revalidate();
			repaint();
		} else if (panelName.equals("login")) {
			getContentPane().removeAll();
			getContentPane().add(Login);
			revalidate();
			repaint();
		} else if (panelName.equals("intro")) {
			getContentPane().removeAll();
			getContentPane().add(Intro);
			revalidate();
			repaint();
		} else if (panelName.equals("resv")) {
			getContentPane().removeAll();
			revalidate();
			getContentPane().add(Resv);
			revalidate();
			repaint();
		} else if (panelName.equals("list_my")) {
			revalidate();
			getContentPane().removeAll();
			getContentPane().add(List_M);
			revalidate();
			repaint();
		} else if (panelName.equals("admin")) {
			revalidate();
			getContentPane().removeAll();
			getContentPane().add(Admin);
			revalidate();
			repaint();
		} else if (panelName.equals("admin_plane")) {
			getContentPane().removeAll();
			getContentPane().add(Admin_Plane);
			revalidate();
			repaint();
		} else if (panelName.equals("admin_user")) {
			getContentPane().removeAll();
			getContentPane().add(Admin_User);
			revalidate();
			repaint();
		} else if (panelName.equals("list_start")) {
			getContentPane().removeAll();
			getContentPane().add(List_Start);
			revalidate();
			repaint();
		} else if (panelName.equals("list_end")) {
			getContentPane().removeAll();
			getContentPane().add(List_End);
			revalidate();
			repaint();
		} /*
			 * else if (panelName.equals("admin")) { getContentPane().removeAll();
			 * getContentPane().add(Admin); revalidate(); repaint();
			 */
		/*
		 * } else if (panelName.equals("list")) { getContentPane().removeAll();
		 * getContentPane().add(List); revalidate(); repaint(); }
		 */
	}

	public FrameMainDAO() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(FrameMainDAO.class.getResource("/img/main.png")));
		setForeground(Color.WHITE);
		setBackground(Color.WHITE);
		setBounds(1200, 100, 950, 770);
		dimen = Toolkit.getDefaultToolkit().getScreenSize();
		dimen2 = getSize();
		xpos = (dimen.width - dimen2.width) / 2;
		ypos = (dimen.height - dimen2.height) / 2;
		setLocation(xpos, ypos);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
}

//list_end â
class list_end extends JPanel {
	private FrameMainDAO f;
	ArrayList<PlaneVO> temp = new ArrayList<>();

	public void making_list(String type) {

		if (type.equals("��߹�ư")) {
			Iterator<PlaneVO> itr = PlaneDAO.s_planeList.iterator();

			while (itr.hasNext()) {
				PlaneVO tmp = itr.next();
				temp.add(tmp);

			}
		} else if (type.equals("������ư")) {
			Iterator<PlaneVO> itr = PlaneDAO.e_planeList.iterator();
			while (itr.hasNext()) {
				PlaneVO tmp = itr.next();
				temp.add(tmp);

			}
		} else {
			System.out.println("making_list �Է¿���");
		}
	}

	public list_end(FrameMainDAO f) {

		this.f = f;
		this.setBackground(Color.WHITE);

		// ��� ��ư
		JButton Button = new JButton("");
		Button.setIcon(new ImageIcon(list_start.class.getResource("/img/list1.png")));
		Button.setEnabled(false);
		// ������ư
		JButton Button_1 = new JButton("");
		Button_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list2.png")));

		// �˻�â
		JTextField textField = new JTextField();
		textField.setText(
				"\uCD9C\uBC1C,\uB3C4\uCC29 \uC120\uD0DD\uD6C4 \uBAA9\uC801\uC9C0\uB97C \uC785\uB825\uD558\uC138\uC694.");
		textField.setColumns(10);

		// �˻� ��ư
		JButton searBtn = new JButton("");
		LineBorder b1 = new LineBorder(Color.WHITE, 1); // ����
		searBtn.setBorder(b1);
		searBtn.setIcon(new ImageIcon(list_start.class.getResource("/img/list4.png")));

		// ����̹���
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(list_start.class.getResource("/img/list5.png")));

		// �����̹���
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list6.png")));

		// ����
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setText("��õ");

		JLabel lblNewLabel_2 = new JLabel("");
		// ��¥
		JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setText("20190708");

		// ����������
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(list_start.class.getResource("/img/list8.png")));
		// �α׾ƿ�
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list7.png")));
		// ��¥
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(list_start.class.getResource("/img/list9.png")));
		// ���
		JTextField textField_1 = new JTextField();
		textField_1.setText("�����");
		textField_1.setColumns(10);
		// ����
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setIcon(new ImageIcon(list_start.class.getResource("/img/list11.png")));

		JScrollPane scrollPane = new JScrollPane();

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(list_start.class.getResource("/img/re5.png")));
		// ���� �̹���
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(list_start.class.getResource("/img/list10.png")));

		// ��������
		JTextField spinner = new JTextField();

		/*
		 * //������ư Ŭ�� Button_1.addMouseListener(new MouseAdapter() {
		 * 
		 * @Override public void mouseClicked(MouseEvent e) { } });
		 * 
		 * textField.addMouseListener(new MouseAdapter() {
		 * 
		 * @Override public void mouseClicked(MouseEvent e) { //�˻�â Ŭ����
		 * textField.setText(""); } });
		 */

		textField_2.addMouseListener(new MouseAdapter() {
			// �����Է�
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_2.setText("");
			}
		});

		textField_3.addMouseListener(new MouseAdapter() {
			// ��¥ �Է�
			@Override
			public void mouseClicked(MouseEvent e) {

			}
		});

		// ���������� �̵�
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("list_my");
			}
		});

		btnNewButton_1.addMouseListener(new MouseAdapter() {
			// �α׾ƿ� ������
			@Override
			public void mouseClicked(MouseEvent e) {
				f.changePanel("login");
			}
		});

		textField_1.addMouseListener(new MouseAdapter() {
			// ��� �Է�
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_1.setText("");
			}
		});

		spinner.setText("1");
		spinner.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ���� ������ ��������
				spinner.setText("");
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(768, Short.MAX_VALUE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 71,
										GroupLayout.PREFERRED_SIZE)
								.addGap(45))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(98).addComponent(label)
								.addContainerGap(152, Short.MAX_VALUE))
						.addGroup(
								gl_contentPane.createSequentialGroup().addGap(398)
										.addComponent(
												btnNewButton_2, GroupLayout.PREFERRED_SIZE, 70,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap(454, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup().addGroup(gl_contentPane
								.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(18, Short.MAX_VALUE)
										.addComponent(lblNewLabel_2).addGap(79)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(Button, GroupLayout.PREFERRED_SIZE, 297,
																GroupLayout.PREFERRED_SIZE)
														.addGap(53).addComponent(
																Button_1, GroupLayout.PREFERRED_SIZE, 298,
																GroupLayout.PREFERRED_SIZE))
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(lblNewLabel).addGap(8)
														.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 128,
																GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(ComponentPlacement.UNRELATED)
														.addComponent(lblNewLabel_1)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 128,
																GroupLayout.PREFERRED_SIZE)
														.addGap(18).addComponent(lblNewLabel_3)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 97,
																GroupLayout.PREFERRED_SIZE)
														.addGap(18).addComponent(lblNewLabel_4)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(spinner, GroupLayout.PREFERRED_SIZE, 49,
																GroupLayout.PREFERRED_SIZE))
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(textField, GroupLayout.PREFERRED_SIZE, 637,
																GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 56,
																GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(ComponentPlacement.RELATED))
								.addGroup(gl_contentPane.createSequentialGroup().addGap(99).addComponent(scrollPane,
										GroupLayout.PREFERRED_SIZE, 689, GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(124, GroupLayout.PREFERRED_SIZE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(217).addComponent(lblNewLabel_2).addGap(496))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(26)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(6).addComponent(btnNewButton_1,
										GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
								.addComponent(btnNewButton, 0, 0, Short.MAX_VALUE))
						.addGap(46)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(Button, 0, 0, Short.MAX_VALUE)
								.addComponent(Button_1, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE))
						.addGap(15)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_3))
								.addComponent(lblNewLabel)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_4).addComponent(spinner, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(11).addComponent(label).addGap(3)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 346, GroupLayout.PREFERRED_SIZE)
						.addGap(21)
						.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGap(31)));

		JList list = new JList();
		list.setForeground(Color.BLACK);
		scrollPane.setViewportView(list);
		this.setLayout(gl_contentPane);
		list.setModel(new AbstractListModel() {

			public Object getElementAt(int index) {
				String temp2;

				temp2 = String.format("%-20s%-35s%-25s%-25s%-25s%-25s%-25s", temp.get(index).getDate(),
						temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(), temp.get(index).getTime(),
						temp.get(index).getS_day(), temp.get(index).getE_day(), temp.get(index).getSeat());
				return temp2;
			}

			@Override
			public int getSize() {

				return temp.size();
			}
		});
		// �˻� ��ư Ŭ���� ����Ʈ ������
		searBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String startL = "", endL = "";
				int num = 0, date = 0;
				startL = textField_1.getText();
				endL = textField_2.getText();
				date = Integer.parseInt(textField_3.getText());
				num = Integer.parseInt(spinner.getText());
				if (spinner.getText().equals(""))
					num = 0;
				System.out.println(startL + endL + date + num);
				temp.clear();
				SortDAO.show_list(temp, "����", startL, endL, date, num);
				list.setModel(new AbstractListModel() {

					public Object getElementAt(int index) {
						String temp2;

						temp2 = String.format("%-20s%-35s%-25s%-25s%-25s%-25s%-25s", temp.get(index).getDate(),
								temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(),
								temp.get(index).getTime(), temp.get(index).getS_day(), temp.get(index).getE_day(),
								temp.get(index).getSeat());
						return temp2;
					}

					@Override
					public int getSize() {

						return temp.size();
					}
				});
				f.revalidate();
			}
		});
		// ���� ��ư Ŭ��
		Button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("����");
				making_list("������ư");
				System.out.println(temp.size());
				list.setModel(new AbstractListModel() {
					public int getSize() {
						return temp.size();
					}

					public Object getElementAt(int index) {
						String temp2;
						temp2 = String.format("%-10s%-40s%-10s%25s%25s%25s%15s", temp.get(index).getDate(),
								temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(),
								temp.get(index).getTime(), temp.get(index).getS_day(), temp.get(index).getE_day(),
								temp.get(index).getSeat());
						return temp2;
					}
				});
				f.revalidate();
			}
		});
		// ����Ʈ���� ���� ���õ�����
		list.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub

				textField_1.setText(temp.get(list.getSelectedIndex()).getS_locate());
				textField_2.setText((temp.get(list.getSelectedIndex()).getE_locate()));
				textField_3.setText((temp.get(list.getSelectedIndex()).getS_day()));

			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			// ���� ��ư
			@Override
			public void mouseClicked(MouseEvent e) {
				f.temp_ep = new PlaneVO(temp.get(list.getSelectedIndex()));
				JOptionPane.showMessageDialog(null, "reserved success");
				f.changePanel("resv");
			}
		});
	}// ������ ��
}// Ŭ���� ��

//list_start â
class list_start extends JPanel {
	private FrameMainDAO f;
	ArrayList<PlaneVO> temp = new ArrayList<>();

	// ��ư ������ ����Ʈ ���� �޼���
	public void making_list(String type) {
		if (type.equals("��߹�ư")) {
			Iterator<PlaneVO> itr = PlaneDAO.s_planeList.iterator();

			while (itr.hasNext()) {
				PlaneVO tmp = itr.next();
				temp.add(tmp);

			}
		} else if (type.equals("����")) {
			Iterator<PlaneVO> itr = PlaneDAO.e_planeList.iterator();
			while (itr.hasNext()) {
				PlaneVO tmp = itr.next();
				temp.add(tmp);
			}
		} else {
			System.out.println("making_list �Է¿���");
		}
	}

	public list_start(FrameMainDAO f) {

		this.f = f;
		this.setBackground(Color.WHITE);

		// ��� ��ư
		JButton Button = new JButton("");
		Button.setIcon(new ImageIcon(list_start.class.getResource("/img/list1.png")));

		// ������ư
		JButton Button_1 = new JButton("");
		Button_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list2.png")));
		Button_1.setEnabled(false);
		// �˻�â
		JTextField textField = new JTextField();
		textField.setText(
				"\uCD9C\uBC1C,\uB3C4\uCC29 \uC120\uD0DD\uD6C4 \uBAA9\uC801\uC9C0\uB97C \uC785\uB825\uD558\uC138\uC694.");
		textField.setColumns(10);

		// �˻� ��ư
		JButton searBtn = new JButton("");
		LineBorder b1 = new LineBorder(Color.WHITE, 1); // ����
		searBtn.setBorder(b1);
		searBtn.setIcon(new ImageIcon(list_start.class.getResource("/img/list4.png")));

		// ����̹���
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(list_start.class.getResource("/img/list5.png")));

		// �����̹���
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list6.png")));

		// ����
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setText("������");

		JLabel lblNewLabel_2 = new JLabel("");
		// ��¥
		JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setText("20190708");

		// ����������
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(list_start.class.getResource("/img/list8.png")));
		// �α׾ƿ�
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon(list_start.class.getResource("/img/list7.png")));
		// ��¥
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(list_start.class.getResource("/img/list9.png")));
		// ���
		JTextField textField_1 = new JTextField();
		textField_1.setText("��õ");
		textField_1.setColumns(10);
		// ����
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.setIcon(new ImageIcon(list_start.class.getResource("/img/list11.png")));

		JScrollPane scrollPane = new JScrollPane();

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(list_start.class.getResource("/img/re5.png")));
		// ���� �̹���
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(list_start.class.getResource("/img/list10.png")));

		// ��������
		JTextField spinner = new JTextField();

		/*
		 * //������ư Ŭ�� Button_1.addMouseListener(new MouseAdapter() {
		 * 
		 * @Override public void mouseClicked(MouseEvent e) { } });
		 * 
		 * textField.addMouseListener(new MouseAdapter() {
		 * 
		 * @Override public void mouseClicked(MouseEvent e) { //�˻�â Ŭ����
		 * textField.setText(""); } });
		 */

		textField_2.addMouseListener(new MouseAdapter() {
			// �����Է�
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_2.setText("");
			}
		});

		textField_3.addMouseListener(new MouseAdapter() {
			// ��¥ �Է�
			@Override
			public void mouseClicked(MouseEvent e) {

			}
		});

		// ���������� �̵�
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("list_my");
			}
		});

		btnNewButton_1.addMouseListener(new MouseAdapter() {
			// �α׾ƿ� ������
			@Override
			public void mouseClicked(MouseEvent e) {
				f.changePanel("login");
			}
		});

		textField_1.addMouseListener(new MouseAdapter() {
			// ��� �Է�
			@Override
			public void mouseClicked(MouseEvent e) {
				textField_1.setText("");
			}
		});

		spinner.setText("1");
		spinner.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ���� ������ ��������
				spinner.setText("");
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(768, Short.MAX_VALUE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 71,
										GroupLayout.PREFERRED_SIZE)
								.addGap(45))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(98).addComponent(label)
								.addContainerGap(152, Short.MAX_VALUE))
						.addGroup(
								gl_contentPane.createSequentialGroup().addGap(398)
										.addComponent(
												btnNewButton_2, GroupLayout.PREFERRED_SIZE, 70,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap(454, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup().addGroup(gl_contentPane
								.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(18, Short.MAX_VALUE)
										.addComponent(lblNewLabel_2).addGap(79)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(Button, GroupLayout.PREFERRED_SIZE, 297,
																GroupLayout.PREFERRED_SIZE)
														.addGap(53).addComponent(
																Button_1, GroupLayout.PREFERRED_SIZE, 298,
																GroupLayout.PREFERRED_SIZE))
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(lblNewLabel).addGap(8)
														.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 128,
																GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(ComponentPlacement.UNRELATED)
														.addComponent(lblNewLabel_1)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 128,
																GroupLayout.PREFERRED_SIZE)
														.addGap(18).addComponent(lblNewLabel_3)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, 97,
																GroupLayout.PREFERRED_SIZE)
														.addGap(18).addComponent(lblNewLabel_4)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(spinner, GroupLayout.PREFERRED_SIZE, 49,
																GroupLayout.PREFERRED_SIZE))
												.addGroup(gl_contentPane.createSequentialGroup()
														.addComponent(textField, GroupLayout.PREFERRED_SIZE, 637,
																GroupLayout.PREFERRED_SIZE)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 56,
																GroupLayout.PREFERRED_SIZE)))
										.addPreferredGap(ComponentPlacement.RELATED))
								.addGroup(gl_contentPane.createSequentialGroup().addGap(99).addComponent(scrollPane,
										GroupLayout.PREFERRED_SIZE, 689, GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(124, GroupLayout.PREFERRED_SIZE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(217).addComponent(lblNewLabel_2).addGap(496))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(26)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(6).addComponent(btnNewButton_1,
										GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
								.addComponent(btnNewButton, 0, 0, Short.MAX_VALUE))
						.addGap(46)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(Button, 0, 0, Short.MAX_VALUE)
								.addComponent(Button_1, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE))
						.addGap(15)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_3))
								.addComponent(lblNewLabel)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_4).addComponent(spinner, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(11).addComponent(label).addGap(3)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 346, GroupLayout.PREFERRED_SIZE)
						.addGap(21)
						.addComponent(btnNewButton_2, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addGap(31)));

		JList list = new JList();
		list.setForeground(Color.BLACK);
		scrollPane.setViewportView(list);
		this.setLayout(gl_contentPane);
		list.setModel(new AbstractListModel() {

			public Object getElementAt(int index) {
				String temp2;

				temp2 = String.format("%-20s%-35s%-25s%-25s%-25s%-25s%-25s", temp.get(index).getDate(),
						temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(), temp.get(index).getTime(),
						temp.get(index).getS_day(), temp.get(index).getE_day(), temp.get(index).getSeat());
				return temp2;
			}

			@Override
			public int getSize() {

				return temp.size();
			}
		});
		// �˻� ��ư Ŭ���� ����Ʈ ������
		searBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String startL = "", endL = "";
				int num = 0, date = 0;
				startL = textField_1.getText();
				endL = textField_2.getText();
				date = Integer.parseInt(textField_3.getText());
				num = Integer.parseInt(spinner.getText());
				if (spinner.getText().equals(""))
					num = 0;
				System.out.println(startL + endL + date + num);
				temp.clear();
				SortDAO.show_list(temp, "���", startL, endL, date, num);
				list.setModel(new AbstractListModel() {

					public Object getElementAt(int index) {
						String temp2;

						temp2 = String.format("%-20s%-35s%-25s%-25s%-25s%-25s%-25s", temp.get(index).getDate(),
								temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(),
								temp.get(index).getTime(), temp.get(index).getS_day(), temp.get(index).getE_day(),
								temp.get(index).getSeat());
						return temp2;
					}

					@Override
					public int getSize() {

						return temp.size();
					}
				});
				f.revalidate();
			}
		});
		// ��� ��ư Ŭ��
		Button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				making_list("��߹�ư");
				list.setModel(new AbstractListModel() {
					public int getSize() {
						return temp.size();
					}

					public Object getElementAt(int index) {
						String temp2;
						temp2 = String.format("%-10s%-40s%-10s%25s%25s%25s%15s", temp.get(index).getDate(),
								temp.get(index).getBrand_plane(), temp.get(index).getNum_plane(),
								temp.get(index).getTime(), temp.get(index).getS_day(), temp.get(index).getE_day(),
								temp.get(index).getSeat());
						return temp2;
					}
				});
				f.revalidate();
			}
		});
		// ����Ʈ���� ���� ���õ�����
		list.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub

				textField_1.setText(temp.get(list.getSelectedIndex()).getS_locate());
				textField_2.setText((temp.get(list.getSelectedIndex()).getE_locate()));
				textField_3.setText((temp.get(list.getSelectedIndex()).getS_day()));

			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			// ���� ��ư
			@Override
			public void mouseClicked(MouseEvent e) {
				f.temp_sp = new PlaneVO(temp.get(list.getSelectedIndex()));
				JOptionPane.showMessageDialog(null, "reserve success");
				f.changePanel("list_end");
			}
		});
	}// ������ ��
}// Ŭ���� ��

//admin_user â
class admin_user extends JPanel {
	private FrameMainDAO f;
	int num = 0;

	public admin_user(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		// �α׾ƿ� ��ư
		JButton logoutBtn = new JButton("");
		logoutBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		logoutBtn.setIcon(new ImageIcon(list_my.class.getResource("/img/list7.png")));
		logoutBtn.setLocation(820, 72);
		logoutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ����ȭ������ ���ư���
				f.changePanel("intro");
			}
		});

		// ���ư��� ��ư
		JButton button = new JButton("");
		button.setLocation(55, 662);

		button.setIcon(new ImageIcon(admin_plane.class.getResource("/img/ad_plane2.png")));

		// �˻��ʵ�
		JTextField textField = new JTextField();
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// �۾���������ϱ�

			}
		});
		textField.setText("\uC0AC\uC6A9\uC790\uC758 \uC774\uB984\uC744 \uC785\uB825\uD558\uC138\uC694");
		textField.setColumns(10);

		// �˻� ��ư
		JButton searBtn = new JButton("");
		LineBorder b1 = new LineBorder(Color.WHITE, 1); // ����
		searBtn.setBorder(b1);

		searBtn.setIcon(new ImageIcon(list_my.class.getResource("/img/list4.png")));

		JScrollPane scrollPane = new JScrollPane();

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(admin_user.class.getResource("/img/ad_user1.png")));

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane
				.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(40, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
												.addComponent(button, GroupLayout.PREFERRED_SIZE, 164,
														GroupLayout.PREFERRED_SIZE)
												.addContainerGap())
										.addGroup(gl_contentPane
												.createSequentialGroup().addComponent(label)
												.addPreferredGap(ComponentPlacement.RELATED, 520, Short.MAX_VALUE)
												.addComponent(
														logoutBtn, GroupLayout.PREFERRED_SIZE, 73,
														GroupLayout.PREFERRED_SIZE)
												.addGap(83))
										.addGroup(gl_contentPane.createSequentialGroup()
												.addPreferredGap(ComponentPlacement.RELATED)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
														.addComponent(scrollPane, Alignment.LEADING)
														.addGroup(Alignment.LEADING, gl_contentPane
																.createSequentialGroup()
																.addComponent(textField, GroupLayout.PREFERRED_SIZE,
																		731, GroupLayout.PREFERRED_SIZE)
																.addGap(18).addComponent(searBtn,
																		GroupLayout.PREFERRED_SIZE, 58,
																		GroupLayout.PREFERRED_SIZE)))
												.addGap(75)))));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(26).addComponent(label).addGap(18))
						.addGroup(Alignment.TRAILING,
								gl_contentPane.createSequentialGroup()
										.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(logoutBtn, GroupLayout.PREFERRED_SIZE, 25,
												GroupLayout.PREFERRED_SIZE)
										.addGap(26)))
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE))
				.addGap(12).addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 442, GroupLayout.PREFERRED_SIZE)
				.addGap(18).addComponent(button, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
				.addGap(46)));

		JList list = new JList();
		scrollPane.setViewportView(list);
		this.setLayout(gl_contentPane);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (num == 0) {
					list.setModel(new AbstractListModel() {
						ArrayList<UserVO> temp = UserDAO.userList;

						public int getSize() {
							return temp.size();
						}

						public Object getElementAt(int index) {
							String temp2;
							temp2 = String.format("%-20s%-20s%-20s%-20s%-20d%-20d", temp.get(index).getName(),
									temp.get(index).getEmail(), temp.get(index).getID(),
									UserDAO.decrypt(temp.get(index).getPw()), temp.get(index).getMileage(),
									temp.get(index).getMy_plane().size());
							return temp2;
						}
						/*
						 * ,temp.get(index).getEmail(),UserDAO.encrypt(temp.get(index).getID()),
						 * UserDAO.encrypt(temp.get(index).getPw())+temp.get(index).getMileage()
						 */

					});
					num++;
				} else if (num == 1) {
					f.changePanel("admin");
					num = 0;
				}

			}
		});
		list.setModel(new AbstractListModel() {
			ArrayList<UserVO> temp = UserDAO.userList;

			public int getSize() {
				return temp.size();
			}

			public Object getElementAt(int index) {
				String temp2;
				temp2 = String.format("%-20s%-20s%-20s%-20s%-20d%-20d", temp.get(index).getName(),
						temp.get(index).getEmail(), temp.get(index).getID(), UserDAO.decrypt(temp.get(index).getPw()),
						temp.get(index).getMileage(), temp.get(index).getMy_plane().size());
				return temp2;
			}
			/*
			 * ,temp.get(index).getEmail(),UserDAO.encrypt(temp.get(index).getID()),
			 * UserDAO.encrypt(temp.get(index).getPw())+temp.get(index).getMileage()
			 */

		});
		// �˻� ��ư Ŭ���� ����Ʈ ������
		searBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �̸����� ã��
				list.setModel(new AbstractListModel() {
					ArrayList<UserVO> temp = UserDAO.userList;

					public int getSize() {
						return temp.size();
					}

					public Object getElementAt(int index) {
						String temp2;
						temp2 = String.format("%-20s%-20s%-20s%-20s%-20d%-20d", temp.get(index).getName(),
								temp.get(index).getEmail(), temp.get(index).getID(),
								UserDAO.decrypt(temp.get(index).getPw()), temp.get(index).getMileage(),
								temp.get(index).getMy_plane().size());
						return temp2;
					}
					/*
					 * ,temp.get(index).getEmail(),UserDAO.encrypt(temp.get(index).getID()),
					 * UserDAO.encrypt(temp.get(index).getPw())+temp.get(index).getMileage()
					 */

				});
			}
		});
	}
}

//admin_plane â
class admin_plane extends JPanel {
	private FrameMainDAO f;

	public admin_plane(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		JScrollPane scrollPane = new JScrollPane();
		// �˻� �ʵ�
		JTextField textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.LEFT);
		textField.setText("\uCC3E\uC73C\uC2E4 \uBAA9\uC801\uC9C0\uB97C \uAC80\uC0C9\uD558\uC138\uC694");
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// �۾���������ϱ�
			}
		});
		textField.setColumns(10);

		// ã�� ��ư
		JButton searBtn = new JButton("");
		LineBorder b1 = new LineBorder(Color.WHITE, 1); // ����
		searBtn.setBorder(b1);
		// �˻� ��ư Ŭ���� ����Ʈ ������
		searBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ������ ã��
			}
		});

		searBtn.setIcon(new ImageIcon(list_my.class.getResource("/img/list4.png")));

		// �α׾ƿ� ��ư
		JButton logoutBtn = new JButton();
		logoutBtn.setIcon(new ImageIcon(list_my.class.getResource("/img/list7.png")));
		logoutBtn.setLocation(820, 72);
		logoutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ����ȭ������ ���ư���
				f.changePanel("intro");
			}
		});

		// �װ��� ���
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(admin_plane.class.getResource("/img/ad_plane.png")));

		// ���ư��� ��ư
		JButton button = new JButton("");
		button.setLocation(55, 662);
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ������ ùȭ������ ���ư���
				f.changePanel("intro");
			}
		});
		button.setIcon(new ImageIcon(admin_plane.class.getResource("/img/ad_plane2.png")));

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(42)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(button, GroupLayout.PREFERRED_SIZE, 165,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap())
								.addGroup(gl_contentPane
										.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane
												.createSequentialGroup().addComponent(label)
												.addPreferredGap(ComponentPlacement.RELATED, 507, Short.MAX_VALUE)
												.addComponent(logoutBtn, GroupLayout.PREFERRED_SIZE, 73,
														GroupLayout.PREFERRED_SIZE)
												.addGap(94))
										.addGroup(gl_contentPane.createSequentialGroup().addGroup(gl_contentPane
												.createParallelGroup(Alignment.TRAILING, false)
												.addGroup(gl_contentPane.createSequentialGroup().addComponent(textField)
														.addPreferredGap(ComponentPlacement.UNRELATED)
														.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 63,
																GroupLayout.PREFERRED_SIZE))
												.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 814,
														GroupLayout.PREFERRED_SIZE))
												.addContainerGap(66, Short.MAX_VALUE))))));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(48).addComponent(logoutBtn,
										GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup().addGap(26).addComponent(label)))
						.addPreferredGap(ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(searBtn, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 443, GroupLayout.PREFERRED_SIZE)
						.addGap(18).addComponent(button, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
						.addGap(46)));

		JList list = new JList();
		scrollPane.setViewportView(list);
		this.setLayout(gl_contentPane);
		list.setModel(new AbstractListModel() {
			ArrayList<PlaneVO> temp = PlaneDAO.s_planeList;

			public int getSize() {
				return temp.size();
			}

			public Object getElementAt(int index) {
				String temp2;
				temp2 = String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s", temp.get(index).getDate(),
						temp.get(index).getS_locate(), temp.get(index).getE_locate(), temp.get(index).getBrand_plane(),
						temp.get(index).getNum_plane(), temp.get(index).getTime(), temp.get(index).getS_day(),
						temp.get(index).getE_day(), temp.get(index).getSeat());
				return temp2;
			}

		});

	}
}

//admin â
class admin extends JPanel {
	private FrameMainDAO f;

	public admin(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		// �α׾ƿ� ��ư
		JButton logoutBtn = new JButton("");
		logoutBtn.setIcon(new ImageIcon(list_my.class.getResource("/img/list7.png")));
		logoutBtn.setLocation(820, 72);

		// �����̹���
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(admin.class.getResource("/img/admin1.png")));

		// �װ��� ��ư
		JButton button = new JButton("");
		LineBorder b1 = new LineBorder(Color.WHITE, 1); // ����
		button.setBorder(b1);
		button.setIcon(new ImageIcon(admin.class.getResource("/img/admin2.png")));

		// ����� ��ư
		JButton UesrBtn = new JButton("");
		LineBorder b2 = new LineBorder(Color.WHITE, 1); // ����
		UesrBtn.setBorder(b2);
		UesrBtn.setIcon(new ImageIcon(admin.class.getResource("/img/admin3.png")));
		// �α׾ƿ�
		logoutBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ����ȭ������ ���ư���
				f.changePanel("intro");
			}
		});
		// �װ��� ��ư
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �װ��� ������� �Ѿ��
				f.changePanel("admin_plane");
			}
		});
		// ����� ���
		UesrBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ����� ������� �Ѿ��
				f.changePanel("admin_user");
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(784, Short.MAX_VALUE)
						.addComponent(logoutBtn, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE).addGap(66))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(188).addComponent(label).addContainerGap(226,
						Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(208)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE).addGap(104)
						.addComponent(UesrBtn, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(251, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addGap(29)
				.addComponent(logoutBtn, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE).addGap(34)
				.addComponent(label).addGap(78)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(1).addComponent(button,
								GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
						.addComponent(UesrBtn, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 51,
								GroupLayout.PREFERRED_SIZE))
				.addContainerGap(85, Short.MAX_VALUE)));
		this.setLayout(gl_contentPane);
	}
}

//list_my â
class list_my extends JPanel {
	private FrameMainDAO f;
	int num = 0;

	public list_my(FrameMainDAO f) {

		this.f = f;
		this.setBackground(Color.WHITE);
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon(list_my.class.getResource("/img/list7.png")));
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(list_my.class.getResource("/img/list_my1.png")));

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(list_my.class.getResource("/img/list_my3.png")));

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);

		JScrollPane scrollPane = new JScrollPane();

		JButton button = new JButton("");

		button.setIcon(new ImageIcon(list_my.class.getResource("/img/list_my4.png")));

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(805, Short.MAX_VALUE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 72, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(69).addGroup(gl_contentPane
								.createParallelGroup(Alignment.LEADING).addComponent(lblNewLabel)
								.addComponent(panel, GroupLayout.DEFAULT_SIZE, 808, Short.MAX_VALUE)
								.addComponent(lblNewLabel_1)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 808, GroupLayout.PREFERRED_SIZE)
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))))
				.addGap(45)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(31)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
						.addGap(12).addComponent(lblNewLabel).addGap(18)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED).addComponent(lblNewLabel_1)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 336, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 42, Short.MAX_VALUE).addGap(46)));
		// ����Ʈ ���
		JList list = new JList();
		list.setToolTipText("");
		scrollPane.setViewportView(list);
		panel.setLayout(null);
		list.setModel(new AbstractListModel() {
			ArrayList<PlaneVO> temp = UserDAO.userList.get(UserDAO.userIndex).getMy_plane();

			public int getSize() {
				return temp.size();
			}

			public Object getElementAt(int index) {
				String temp2;
				temp2 = String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s", temp.get(index).getDate(),
						temp.get(index).getS_locate(), temp.get(index).getE_locate(), temp.get(index).getBrand_plane(),
						temp.get(index).getNum_plane(), temp.get(index).getTime(), temp.get(index).getS_day(),
						temp.get(index).getE_day(), temp.get(index).getSeat());
				return temp2;
			}

		});
		// ���ϸ���
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("-������330", Font.PLAIN, 17));
		lblNewLabel_3.setText(String.valueOf(UserDAO.userList.get(UserDAO.userIndex).getMileage()));// ������� ���ϸ���
		lblNewLabel_3.setBounds(432, 40, 349, 29);
		panel.add(lblNewLabel_3);

		// �̸���
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_2.setFont(new Font("-������330", Font.PLAIN, 19));
		lblNewLabel_2.setText(UserDAO.userList.get(UserDAO.userIndex).getEmail()); // ������� �̸���
		lblNewLabel_2.setBounds(0, 40, 426, 29);
		panel.add(lblNewLabel_2);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(list_my.class.getResource("/img/list_my2.png")));
		label.setBounds(0, 0, 781, 104);
		panel.add(label);
		this.setLayout(gl_contentPane);
		revalidate();
		// �α׾ƿ� ��ư
		btnNewButton.addMouseListener(new MouseAdapter() {
			// �α׾ƿ� ������
			@Override
			public void mouseClicked(MouseEvent e) {

				f.changePanel("login");
			}
		});
		// �� �����ϱ� ��ư
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (num == 0) {
					lblNewLabel_3.setText(String.valueOf(UserDAO.userList.get(UserDAO.userIndex).getMileage()));// �������
																												// ���ϸ���
					lblNewLabel_2.setText(UserDAO.userList.get(UserDAO.userIndex).getEmail()); // ������� �̸���
					list.setModel(new AbstractListModel() {
						ArrayList<PlaneVO> temp = UserDAO.userList.get(UserDAO.userIndex).getMy_plane();

						public int getSize() {
							return temp.size();
						}

						public Object getElementAt(int index) {
							String temp2;
							temp2 = String.format("%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s",
									temp.get(index).getDate(), temp.get(index).getS_locate(),
									temp.get(index).getE_locate(), temp.get(index).getBrand_plane(),
									temp.get(index).getNum_plane(), temp.get(index).getTime(),
									temp.get(index).getS_day(), temp.get(index).getE_day(), temp.get(index).getSeat());
							return temp2;
						}

					});
					num++;
				} else if (num == 1) {
					try {
						UserDAO.upload_user();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// ��� ����ȭ������ ��
					f.changePanel("list_start");
					num = 0;
				}

			}
		});
	}
}

//resv â
class resv extends JPanel {
	private FrameMainDAO f;
	int num = 0;

	public resv(FrameMainDAO f) {
		this.setBackground(Color.WHITE);
		// �г��߰�(����ȭ��)
		ImageIcon ic = new ImageIcon("./src/img/re1.png");

		JButton btnNewButton = new JButton("");

		btnNewButton.setIcon(new ImageIcon(resv.class.getResource("/img/re2.png")));

		// ��� ȭ��
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setForeground(Color.WHITE);

		// �װ����̸�
		JLabel lblNewLabel = new JLabel();
		lblNewLabel.setBounds(214, 12, 289, 26);

		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("-������330", Font.PLAIN, 16));
		lblNewLabel.setText(f.temp_sp.getBrand_plane());// �װ��� �̸� ���� /��)�ƽþƳ� �װ�
		panel.add(lblNewLabel);

		// ���� ����
		JLabel lblA = new JLabel();
		lblA.setText(f.temp_sp.getNum_plane()); // �̸� ����
		lblA.setFont(new Font("-������330", Font.PLAIN, 15));
		lblA.setHorizontalAlignment(SwingConstants.CENTER);
		lblA.setBounds(411, 52, 116, 24);

		panel.add(lblA);

		// �����
		JLabel lblNewLabel_1 = new JLabel();
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("-������330", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(53, 111, 147, 24);
		lblNewLabel_1.setText(f.temp_sp.getS_locate()); // �̸� ����
		panel.add(lblNewLabel_1);

		// ������
		JLabel lblNewLabel_2 = new JLabel();
		lblNewLabel_2.setBounds(367, 158, 62, 18);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("-������330", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(536, 111, 147, 24);
		lblNewLabel_2.setText(f.temp_sp.getE_locate()); // �̸� ����
		panel.add(lblNewLabel_2);

		// ����̹���
		JLabel label_3 = new JLabel("");
		label_3.setBounds(4, 5, 720, 197);
		label_3.setIcon(new ImageIcon(resv.class.getResource("/img/re4.png")));
		panel.add(label_3);

		// ���� ȭ��
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setLayout(null);

		// �װ��� �̸�
		JLabel label_1 = new JLabel();
		label_1.setText(f.temp_ep.getBrand_plane()); // �װ��� �̸� ���� /��)�ƽþƳ� �װ�
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("-������330", Font.PLAIN, 16));
		label_1.setBounds(226, 12, 261, 24);
		panel_1.add(label_1);

		// ���� �̸�
		JLabel label_2 = new JLabel();
		label_2.setText(f.temp_ep.getNum_plane()); // �̸�����
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("-������330", Font.PLAIN, 15));
		label_2.setBounds(411, 53, 116, 24);
		panel_1.add(label_2);

		// �����
		JLabel label_4 = new JLabel();
		label_4.setText(f.temp_ep.getS_locate()); // �̸�����
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setFont(new Font("-������330", Font.PLAIN, 16));
		label_4.setBounds(53, 111, 147, 24);
		panel_1.add(label_4);

		// ������
		JLabel label_5 = new JLabel();
		label_5.setText(f.temp_ep.getE_locate()); // �̸�����
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("-������330", Font.PLAIN, 16));
		label_5.setBounds(536, 111, 147, 24);
		panel_1.add(label_5);

		btnNewButton.addMouseListener(new MouseAdapter() {
			// Ȯ�� ��ư

			@Override
			public void mouseClicked(MouseEvent arg0) {

				lblNewLabel.setText(f.temp_sp.getBrand_plane());// �װ��� �̸� ���� /��)�ƽþƳ� �װ�
				lblA.setText(f.temp_sp.getNum_plane()); // �̸� ����
				lblNewLabel_1.setText(f.temp_sp.getS_locate());
				lblNewLabel_2.setText(f.temp_sp.getE_locate()); // �̸� ����

				label_1.setText(f.temp_ep.getBrand_plane());
				label_2.setText(f.temp_ep.getNum_plane());
				label_4.setText(f.temp_ep.getS_locate());
				label_5.setText(f.temp_ep.getE_locate());
				if (num == 1) {
					UserDAO.userList.get(UserDAO.userIndex).getMy_plane().add(f.temp_sp);
					UserDAO.userList.get(UserDAO.userIndex).getMy_plane().add(f.temp_ep);
					UserDAO.userList.get(UserDAO.userIndex)
							.setMileage(UserDAO.userList.get(UserDAO.userIndex).getMileage() + 1000);

					f.revalidate();
					f.changePanel("list_my");
					num = 0;
				}
				num++;

			}
		});
		// ��� ȭ��
		JLabel label = new JLabel("");
		label.setBounds(4, 5, 720, 197);
		label.setIcon(new ImageIcon(resv.class.getResource("/img/re4.png")));
		panel_1.add(label);

		JLabel label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon(resv.class.getResource("/img/re7.png")));

		JLabel label_7 = new JLabel("");
		label_7.setIcon(new ImageIcon(resv.class.getResource("/img/re6.png")));
		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(326).addComponent(btnNewButton,
								GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(86).addGroup(gl_contentPane
								.createParallelGroup(Alignment.LEADING)
								.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 727, GroupLayout.PREFERRED_SIZE)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 727, GroupLayout.PREFERRED_SIZE)
								.addComponent(label_6).addComponent(label_7))))
				.addContainerGap(109, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING).addGroup(gl_contentPane
				.createSequentialGroup().addGap(46).addComponent(label_7).addPreferredGap(ComponentPlacement.RELATED)
				.addComponent(panel, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE).addGap(36)
				.addComponent(label_6).addPreferredGap(ComponentPlacement.RELATED)
				.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE).addGap(35)
				.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE).addGap(62)));
		panel.setLayout(null);

		this.setLayout(gl_contentPane);
	}
}

//intro â
class intro extends JPanel {
	private FrameMainDAO f;

	public intro(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(intro.class.getResource("/img/ve1.png")));

		JButton btnNewButton = new JButton("");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("login");
			}
		});
		btnNewButton.setIcon(new ImageIcon(intro.class.getResource("/img/ve3.png")));
		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane
				.setHorizontalGroup(
						gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup().addContainerGap(233, Short.MAX_VALUE)
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 500,
												GroupLayout.PREFERRED_SIZE)
										.addGap(189))
								.addGroup(Alignment.LEADING,
										gl_contentPane.createSequentialGroup().addGap(360)
												.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 173,
														GroupLayout.PREFERRED_SIZE)
												.addContainerGap(389, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup().addGap(76).addComponent(lblNewLabel).addGap(78)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(90, Short.MAX_VALUE)));
		this.setLayout(gl_contentPane);
	}

}

//�α��� â
class login extends JPanel {
	private FrameMainDAO f;
	private JTextField textField;
	private JPasswordField textField_1;

	public login(FrameMainDAO f) {
		this.f = f;
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login1.png")));
		this.setBackground(Color.WHITE);
		textField = new JTextField();
		textField.addMouseListener(new MouseAdapter() {
			@Override

			public void mouseClicked(MouseEvent arg0) {
				textField.setText("");
			}
		});
		textField.setText("\uC544\uC774\uB514\uB97C \uC785\uB825\uD558\uC138\uC694");
		textField.setForeground(Color.GRAY);
		textField.setColumns(10);

		textField_1 = new JPasswordField();
		textField_1.addMouseListener(new MouseAdapter() {
			@Override

			public void mouseClicked(MouseEvent e) {
				textField_1.setText("");
			}
		});

		textField_1.setText("1234");
		textField_1.setForeground(Color.GRAY);
		textField_1.setColumns(10);

		JButton btnNewButton = new JButton("New button");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String id;
				String pw;
				int choice;
				id = textField.getText();
				pw = textField_1.getText();
				choice = UserDAO.login(id, pw);
				if (choice == -1) {
					f.changePanel("admin");
					textField.setText("���̵� �Է��ϼ���");
					textField_1.setText("0000");
				} else if (choice == 1) {
					f.changePanel("list_start");// list �ιٲٱ�
					textField.setText("���̵� �Է��ϼ���");
					textField_1.setText("0000");
				} else if (choice == 0) {
					JOptionPane.showMessageDialog(null, "�� wrong id & pw �� ");
				} else {
					JOptionPane.showMessageDialog(null, "��Login Action fail�� ");
					textField.setText("���̵� �Է��ϼ���");
					textField_1.setText("0000");
				}
			}

		});
		btnNewButton.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login_but.png")));

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login2.png")));

		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/login3.png")));

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setIcon(new ImageIcon(FrameMainDAO.class.getResource("/img/join_but.png")));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				f.changePanel("join");
				textField.setText("���̵� �Է��ϼ���");
				textField_1.setText("0000");
			}
		});

		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addGap(77)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
						.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false).addComponent(textField_1)
								.addComponent(textField, GroupLayout.DEFAULT_SIZE, 482, Short.MAX_VALUE))
						.addGap(51)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 189, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 740, GroupLayout.PREFERRED_SIZE))
				.addContainerGap(105, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup().addGap(52)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup().addGap(10)
										.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 529,
												GroupLayout.PREFERRED_SIZE)
										.addGap(41).addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 119,
												GroupLayout.PREFERRED_SIZE))
								.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 757, Short.MAX_VALUE))
						.addGap(113)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap()
				.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 324, GroupLayout.PREFERRED_SIZE).addGap(51)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnNewButton, 0, 0, Short.MAX_VALUE))
				.addGap(18).addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
				.addGap(18)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 95, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 48, GroupLayout.PREFERRED_SIZE))
				.addGap(28)));
		this.setLayout(gl_contentPane);
	}
}

//ȸ������â
class join extends JPanel {
	private FrameMainDAO f;
	private JTextField textField_2;
	private JPasswordField passwordField;
	private JTextField textField;
	private JTextField textField_1;

	public join(FrameMainDAO f) {
		this.f = f;
		this.setBackground(Color.WHITE);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel lblJoin = new JLabel("");
		lblJoin.setIcon(new ImageIcon(join.class.getResource("/img/join1.PNG")));

		JButton button = new JButton("");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ���ԿϷ��ư
				String name, ID, pw, email;
				name = textField.getText();
				ID = textField_1.getText();
				pw = passwordField.getText();
				email = textField_2.getText();
				UserDAO.join(name, ID, pw, email);
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				passwordField.setText("");
				f.changePanel("login");
			}
		});
		button.setIcon(new ImageIcon(join.class.getResource("/img/join4.png")));

		JButton btnNewButton = new JButton("");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setText("");
				textField_1.setText("");

				textField_2.setText("");
				passwordField.setText("");
				f.changePanel("login");
			}
		});
		btnNewButton.setIcon(new ImageIcon(join.class.getResource("/img/join5.png")));

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(join.class.getResource("/img/join8.png")));

		textField = new JTextField();
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setColumns(10);

		passwordField = new JPasswordField();

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(this);
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(38).addComponent(lblJoin))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(153)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 217, GroupLayout.PREFERRED_SIZE)
								.addGap(18)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(textField, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 365,
												GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(192)
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 243, GroupLayout.PREFERRED_SIZE)
								.addGap(32).addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 244,
										GroupLayout.PREFERRED_SIZE)))
				.addContainerGap(41, Short.MAX_VALUE)));
		gl_contentPane.setVerticalGroup(gl_contentPane.createParallelGroup(Alignment.LEADING).addGroup(gl_contentPane
				.createSequentialGroup().addContainerGap().addComponent(lblJoin).addGap(18)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup().addGap(48).addComponent(label,
								GroupLayout.PREFERRED_SIZE, 298, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup().addGap(60)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
								.addGap(12)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)))
				.addGap(66)
				.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE))
				.addGap(93)));

		this.setLayout(gl_contentPane);
	}
}